﻿using SurveyApp1.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SurveyApp1
{
    public partial class SurveyForm : System.Web.UI.Page
    {
        Service2Client sr = new Service2Client();
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            // Get the data from the form
            string fullName = FullName.Text;
            string email = Email.Text;
            DateTime dateOfBirth = DateTime.Parse(DateOfBirth.Text);
            string contactNumber = ContactNumber.Text;

            bool favoriteFoodPizza = FavoriteFoodPizza.Checked;
            bool favoriteFoodPasta = FavoriteFoodPasta.Checked;
            bool favoriteFoodPapWors = FavoriteFoodPapWors.Checked;
            bool favoriteFoodOther = FavoriteFoodOther.Checked;

            int moviesRating = int.Parse(MoviesRating.SelectedValue);
            int eatOutRating = int.Parse(EatOutRating.SelectedValue);
            int listenToRadioRating = int.Parse(ListenToRadioRating.SelectedValue);
            int watchTVRating = int.Parse(WatchTVRating.SelectedValue);

            // Call the SubmitSurveyResponse method to submit the survey response
            sr.SubmitSurveyResponse(fullName, email, dateOfBirth, contactNumber,
                                    favoriteFoodPizza, favoriteFoodPasta, favoriteFoodPapWors, favoriteFoodOther,
                                    moviesRating, eatOutRating, listenToRadioRating, watchTVRating);

            // Clear the form
            FullName.Text = "";
            Email.Text = "";
            DateOfBirth.Text = "";
            ContactNumber.Text = "";

            FavoriteFoodPizza.Checked = false;
            FavoriteFoodPasta.Checked = false;
            FavoriteFoodPapWors.Checked = false;
            FavoriteFoodOther.Checked = false;

            MoviesRating.ClearSelection();
            EatOutRating.ClearSelection();
            ListenToRadioRating.ClearSelection();
            WatchTVRating.ClearSelection();
        }
    }
}