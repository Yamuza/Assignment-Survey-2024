﻿using SurveyApp1.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SurveyApp1
{
    public partial class SurveyResults : System.Web.UI.Page
    {

        readonly Service2Client sr = new Service2Client();

       // private readonly Service2Client _serviceClient = new Service2Client();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                RefreshData();
            }
        }

        protected void RefreshButton_Click(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void RefreshData()
        {
            // Call the GetSurveyStatistics method to get the survey statistics
             SurveyStatistics statistics = sr.GetSurveyStatistics();
          //  var statistics = _serviceClient.GetSurveyStatistics();

            // Display the data on the page
            TotalSurveys1DataLabel.Text = statistics.TotalSurveys.ToString();
            AverageAge1DataLabel.Text = statistics.AverageAge.ToString("0.0");
            OldestParticipantAgeDataLabel.Text = statistics.OldestParticipantAge.ToString();
            YoungestParticipantAgeDataLabel.Text = statistics.YoungestParticipantAge.ToString();
            PercentageWhoLikePizzaDataLabel.Text = statistics.PercentageWhoLikePizza.ToString("0.0");
            PercentageWhoLikePastaDataLabel.Text = statistics.PercentageWhoLikePasta.ToString("0.0");
            PercentageWhoLikePapWorsDataLabel.Text = statistics.PercentageWhoLikePapWors.ToString("0.0");
            AverageMoviesRatingDataLabel.Text = statistics.AverageMoviesRating.ToString("0.0");
            AverageEatOutRatingDataLabel.Text = statistics.AverageEatOutRating.ToString("0.0");
            AverageListenToRadioRatingDataLabel.Text = statistics.AverageListenToRadioRating.ToString("0.0");
            AverageWatchTVRatingDataLabel.Text = statistics.AverageWatchTVRating.ToString("0.0");
        }
    }
}