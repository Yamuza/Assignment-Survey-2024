﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SurveyApp1DB
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service2" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service2.svc or Service2.svc.cs at the Solution Explorer and start debugging.
    public class Service2 : IService2
    {
        DataClasses2DataContext db = new DataClasses2DataContext();

        public void SubmitSurveyResponse(string fullName, string email, DateTime dateOfBirth, string contactNumber,
                              bool favoriteFoodPizza, bool favoriteFoodPasta, bool favoriteFoodPapWors, bool favoriteFoodOther,
                              int moviesRating, int eatOutRating, int listenToRadioRating, int watchTVRating)
        {
            try
            {
                if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(contactNumber))
                {
                    throw new FaultException("Full name, email, and contact number cannot be null or empty.");
                }

                if (dateOfBirth > DateTime.Now)
                {
                    throw new FaultException("Date of birth cannot be in the future.");
                }

                // Validate ratings
                if (moviesRating < 1 || moviesRating > 10 || eatOutRating < 1 || eatOutRating > 10 ||
                    listenToRadioRating < 1 || listenToRadioRating > 10 || watchTVRating < 1 || watchTVRating > 10)
                {
                    throw new FaultException("All ratings must be between 1 and 10.");
                }

                Survey2 survey = new Survey2
                {
                    FullName = fullName,
                    Email = email,
                    DateOfBirth = dateOfBirth,
                    ContactNumber = contactNumber,
                    FavoriteFoodPizza = favoriteFoodPizza,
                    FavoriteFoodPasta = favoriteFoodPasta,
                    FavoriteFoodPapWors = favoriteFoodPapWors,
                    FavoriteFoodOther = favoriteFoodOther,
                    MoviesRating = moviesRating,
                    EatOutRating = eatOutRating,
                    ListenToRadioRating = listenToRadioRating,
                    WatchTVRating = watchTVRating
                };

                db.Survey2s.InsertOnSubmit(survey);
                db.SubmitChanges();

            }
            catch (Exception ex)
            {
                ex.GetBaseException();
            }
        }


        public List<SurveyResponse> GetSurveyResponses()
        {
            // Assuming I have a mapping function to convert Survey entities to SurveyResponse objects
            return db.Survey2s.Select(survey => new SurveyResponse
            {
                FullName = survey.FullName,
                Email = survey.Email,
                DateOfBirth = survey.DateOfBirth,
                ContactNumber = survey.ContactNumber,
                FavoriteFoodPizza = (bool)survey.FavoriteFoodPizza,
                FavoriteFoodPasta = (bool)survey.FavoriteFoodPasta,
                FavoriteFoodPapWors = (bool)survey.FavoriteFoodPapWors,
                FavoriteFoodOther = (bool)survey.FavoriteFoodOther,
                MoviesRating = survey.MoviesRating,
                EatOutRating = survey.EatOutRating,
                ListenToRadioRating = survey.ListenToRadioRating,
                WatchTVRating = survey.WatchTVRating
            }).ToList();
        }

        public SurveyStatistics GetSurveyStatistics()
        {
            SurveyStatistics statistics = new SurveyStatistics();

            // Total Surveys
            statistics.TotalSurveys = db.Survey2s.Count();

            // Average Age, Oldest Participant Age, Youngest Participant Age
            DateTime today = DateTime.Today;
            var ages = db.Survey2s.Select(s => (today - s.DateOfBirth).TotalDays / 365.25);
            statistics.AverageAge = ages.Average();
            statistics.OldestParticipantAge = (int)ages.Max();
            statistics.YoungestParticipantAge = (int)ages.Min();

            // Percentage Who Like Pizza, Pasta, Watch TV, Listen to Radio
            statistics.PercentageWhoLikePizza = db.Survey2s.Count(s => (bool)s.FavoriteFoodPizza) * 100.0 / statistics.TotalSurveys;
            statistics.PercentageWhoLikePasta = db.Survey2s.Count(s => (bool)s.FavoriteFoodPasta) * 100.0 / statistics.TotalSurveys;

            // Average Ratings
            statistics.AverageMoviesRating = db.Survey2s.Average(s => s.MoviesRating);
            statistics.AverageEatOutRating = db.Survey2s.Average(s => s.EatOutRating);
            statistics.AverageListenToRadioRating = db.Survey2s.Average(s => s.ListenToRadioRating);
            statistics.AverageWatchTVRating = db.Survey2s.Average(s => s.WatchTVRating);

            return statistics;
        }
    }
}
