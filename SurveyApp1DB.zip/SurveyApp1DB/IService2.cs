﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SurveyApp1DB
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService2" in both code and config file together.
    [ServiceContract]
    public interface IService2
    {
        [OperationContract]
        void SubmitSurveyResponse(string fullName, string email, DateTime dateOfBirth, string contactNumber,
                               bool favoriteFoodPizza, bool favoriteFoodPasta, bool favoriteFoodPapWors, bool favoriteFoodOther,
                               int moviesRating, int eatOutRating, int listenToRadioRating, int watchTVRating);

        [OperationContract]
        List<SurveyResponse> GetSurveyResponses();

        [OperationContract]
        SurveyStatistics GetSurveyStatistics();
    }

    [DataContract]
    public class SurveyResponse
    {
        [DataMember]
        public string FullName { get; set; }

        [DataMember]
        public string Email { get; set; }

        [DataMember]
        public DateTime DateOfBirth { get; set; }

        [DataMember]
        public string ContactNumber { get; set; }

        [DataMember]
        public bool FavoriteFoodPizza { get; set; }

        [DataMember]
        public bool FavoriteFoodPasta { get; set; }

        [DataMember]
        public bool FavoriteFoodPapWors { get; set; }

        [DataMember]
        public bool FavoriteFoodOther { get; set; }

        [DataMember]
        public int MoviesRating { get; set; }

        [DataMember]
        public int EatOutRating { get; set; }

        [DataMember]
        public int ListenToRadioRating { get; set; }

        [DataMember]
        public int WatchTVRating { get; set; }
    }

    [DataContract]
    public class SurveyStatistics
    {
        [DataMember]
        public int TotalSurveys { get; set; }

        [DataMember]
        public double AverageAge { get; set; }

        [DataMember]
        public int OldestParticipantAge { get; set; }

        [DataMember]
        public int YoungestParticipantAge { get; set; }

        [DataMember]
        public double PercentageWhoLikePizza { get; set; }

        [DataMember]
        public double PercentageWhoLikePasta { get; set; }

        [DataMember]
        public double PercentageWhoLikePapWors { get; set; }

        [DataMember]
        public double PercentageWhoLikeOther { get; set; }

        [DataMember]
        public double AverageMoviesRating { get; set; }

        [DataMember]
        public double AverageEatOutRating { get; set; }

        [DataMember]
        public double AverageListenToRadioRating { get; set; }

        [DataMember]
        public double AverageWatchTVRating { get; set; }
    }
}
